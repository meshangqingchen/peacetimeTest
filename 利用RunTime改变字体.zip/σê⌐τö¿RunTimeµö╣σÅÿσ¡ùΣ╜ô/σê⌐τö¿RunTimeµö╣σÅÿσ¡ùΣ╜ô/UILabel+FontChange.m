//
//  UILabel+FontChange.m
//  利用RunTime改变字体
//
//  Created by 3D on 16/6/24.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "UILabel+FontChange.h"
#import <objc/runtime.h>
#define CustomFontName @"FZLBJW--GB1-0"

@implementation UILabel (FontChange)

+(void)load{

    static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
    //系统的方法
    SEL systemSel = @selector(willMoveToSuperview:);
    //自己将要实现的方法
    SEL swizzSel = @selector(myWillMoveToSuperview:);
    
    //两个方法的Method
    Method systemSelMethod = class_getInstanceMethod([self class], systemSel);
    Method swizzSelMethod = class_getInstanceMethod([self class], swizzSel);
    /*cls,将一个新方法添加到一个给定名称和实现的类中。是的，如果该方法成功地添加了，否则为“（例如，类已经包含了一个以该名称实现的方法）。
    name 指定添加的方法的名称的选择器
     */
//    class_addMethod(__unsafe_unretained Class cls, SEL name, <#IMP imp#>, <#const char *types#>)
    BOOL isAdd = class_addMethod(self, systemSel, method_getImplementation(swizzSelMethod), method_getTypeEncoding(swizzSelMethod));
    
    if (isAdd) {
         class_replaceMethod(self, swizzSel, method_getImplementation(systemSelMethod), method_getTypeEncoding(systemSelMethod));
    }else{
        method_exchangeImplementations(systemSelMethod, swizzSelMethod);
    }
    
});
}

-(void)myWillMoveToSuperview:(UIView *)newSuperView{
    [self myWillMoveToSuperview:newSuperView];

    if (self) {
        
        if (self.tag == 10086) {
            self.font = [UIFont systemFontOfSize:self.font.pointSize];
        } else {
            if ([UIFont fontNamesForFamilyName:CustomFontName])
                self.font  = [UIFont fontWithName:CustomFontName size:self.font.pointSize];
        }

    }
}

@end













