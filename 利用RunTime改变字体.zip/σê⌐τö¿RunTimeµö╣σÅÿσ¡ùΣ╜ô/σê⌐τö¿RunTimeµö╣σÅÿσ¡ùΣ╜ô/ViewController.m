//
//  ViewController.m
//  利用RunTime改变字体
//
//  Created by 3D on 16/6/24.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    UILabel *lable = [[UILabel alloc]init];
    [self.view addSubview:lable];
    lable.frame = CGRectMake(100, 200, 100, 50);
    lable.text = @"Welocome";
    
//    NSTextAlignment//   NSTextAlignmentCenter
    lable.textAlignment = NSTextAlignmentCenter;
    lable.textColor = [UIColor blackColor];
//    lable.font = [UIFont fontWithName:@"FZLBJW--GB1-0" size:17.0];
    lable.backgroundColor = [UIColor yellowColor];
    int aaaa = 0;
    for (NSString *familyName in [UIFont familyNames]) {
        NSLog(@"%@ , %d",familyName,aaaa++);//输出字体族科名字
    
        for (NSString *fontName in [UIFont fontNamesForFamilyName:familyName]) {
            NSLog(@"%@",fontName);       //输出字体族科下字样名字
        }
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
