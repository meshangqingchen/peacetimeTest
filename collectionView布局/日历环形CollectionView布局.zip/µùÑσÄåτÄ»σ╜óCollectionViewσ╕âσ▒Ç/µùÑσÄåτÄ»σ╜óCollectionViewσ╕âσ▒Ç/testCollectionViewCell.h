//
//  testCollectionViewCell.h
//  collectionView瀑布流参差不齐
//
//  Created by 3D on 16/7/19.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface testCollectionViewCell : UICollectionViewCell

@property(nonatomic,strong)UILabel *lable;
@end
