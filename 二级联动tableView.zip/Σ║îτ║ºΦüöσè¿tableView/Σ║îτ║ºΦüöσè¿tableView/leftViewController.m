//
//  leftViewController.m
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "leftViewController.h"
#import "rightViewController.h"

@interface leftViewController ()<UITableViewDataSource,UITableViewDelegate,rightViewControllerDeldgate>
@property(nonatomic,strong)UITableView *leftTableView;
@property(nonatomic,strong)NSArray *leftDataArr;
@property(nonatomic,strong)rightViewController *rightVC;
@end

@implementation leftViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:self.leftTableView];
    [self creatRightVC];
}

-(void)creatRightVC{
   
    self.rightVC = [rightViewController new];
    
    self.rightVC.delegate = self;
    [self addChildViewController:_rightVC];
    [self.view addSubview:_rightVC.view];
}




-(UITableView *)leftTableView{
    if (!_leftTableView) {
        _leftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 120, self.view.frame.size.height) style:UITableViewStylePlain];
        _leftTableView.showsVerticalScrollIndicator = NO;
        _leftTableView.delegate = self;
        _leftTableView.dataSource = self;
        [_leftTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell11"];
    }
    return _leftTableView;
}

-(NSArray *)leftDataArr{
    if (!_leftDataArr) {
        _leftDataArr = @[@"第一类",
                         @"第二类",
                         @"第三类",
                         @"第四类",
                         @"第五类",
                         @"第六类",
                         @"第七类",
                         @"第八类",
                         @"第九类",
                         @"第十类",
                         @"第十一类",
                         @"第十二类",
                         @"第十三类",
                         @"第十四类",
                         @"第十五类",
                         @"第十六类",
                         @"第十七类",
                         @"第十八类",
                         @"第十九类",
                         @"第二十类",
                         @"第二十一类"
                         ];
    }
    return _leftDataArr;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.leftDataArr.count;

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell11" forIndexPath:indexPath];
    cell.textLabel.text = self.leftDataArr[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"-----%ld",indexPath.row);
    if (self.rightVC) {
        [self.rightVC scrollToSelectIndexPath:indexPath withRightTableViewScroll:NO];
    }
}

/*
 代理右边选择时执行代理.
 */
-(void)rightViewControllerDelegate:(rightViewController *)vc withIndexPatch:(NSIndexPath *)ptch{
    [self.leftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:ptch.section inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
}


-(void)rightViewControllerDelegateHeaderViewAppear:(rightViewController*)vc withIndexPatch:(NSInteger)section{
    [self.leftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:section inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
}

-(void)rightViewControllerDelegateHeaderViewdisappear:(rightViewController *)vc withIndexPatch:(NSInteger)section{
[self.leftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:section inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
