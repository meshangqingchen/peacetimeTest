//
//  ViewController.m
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "ViewController.h"
#import "leftViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *bution = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 50)];
    bution.center = self.view.center;
    bution.backgroundColor = [UIColor redColor];
    [bution addTarget:self action:@selector(butionCleck:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bution];
}

-(void)butionCleck:(UIButton *)sender{
    leftViewController *leftVC = [leftViewController new];
    [self.navigationController pushViewController:leftVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
