//
//  main.m
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
