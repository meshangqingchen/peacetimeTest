//
//  rightViewController.m
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "rightViewController.h"

@interface rightViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *rightTableView;
@property(nonatomic,strong)NSArray *rightDataArr;
@property(nonatomic,assign)BOOL isScrollUp;
@property(nonatomic, assign)CGFloat lastOffsetY;//滚动即将结束时scrollView的偏移量

@property(nonatomic,assign)BOOL ifScroll; //当左边cell点击-> 右边滑动-> 右边滑动头消失头出现就会执行代理->代理方法再让左边滑动      给个boll值设置为NO就是为了 点击左边cell右边头出现或者消失 都不执行代理方法 左边也不会滑动.

@end

@implementation rightViewController

-(UITableView *)rightTableView{
    if (!_rightTableView) {
        _rightTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0,self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
        
        
        _rightTableView.showsVerticalScrollIndicator = NO;
        _rightTableView.delegate = self;
        _rightTableView.dataSource =self;
        [_rightTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
        [_rightTableView registerClass:[UITableViewHeaderFooterView class] forHeaderFooterViewReuseIdentifier:@"headerView"];
    }
    return _rightTableView;
}

-(NSArray *)rightDataArr{
    if (!_rightDataArr) {
        _rightDataArr =
  @[
  @[@"1橘子",@"西瓜",@"哈密瓜",@"苹果",@"柚子",@"香蕉"],
  @[@"2华为手机",@"苹果5",@"苹果5s",@"苹果6",@"苹果6+",@"苹果6s",@"苹果6s+"],
  @[@"3联想电脑",@"华硕电脑",@"MAC"],
  @[@"4鸡肉",@"鸭肉",@"牛肉",@"猪肉",@"羊肉"],
  @[@"5香菇",@"蘑菇",@"大头菜",@"青椒"],
  @[@"6花生油",@"大豆油",@"葵花籽油",@"芝麻香油"],
  @[@"7花椒",@"陈皮",@"八角"],
  @[@"8橘子",@"西瓜",@"哈密瓜",@"苹果",@"柚子",@"香蕉"],
  @[@"9华为手机",@"苹果5",@"苹果5s",@"苹果6",@"苹果6+",@"苹果6s",@"苹果6s+"],
  @[@"10联想电脑",@"华硕电脑",@"MAC"],
  @[@"11鸡肉",@"鸭肉",@"牛肉",@"猪肉",@"羊肉"],
  @[@"12香菇",@"蘑菇",@"大头菜",@"青椒"],
  @[@"13花生油",@"大豆油",@"葵花籽油",@"芝麻香油"],
  @[@"14花椒",@"陈皮",@"八角"],
  @[@"15橘子",@"西瓜",@"哈密瓜",@"苹果",@"柚子",@"香蕉"],
  @[@"16华为手机",@"苹果5",@"苹果5s",@"苹果6",@"苹果6+",@"苹果6s",@"苹果6s+"],
  @[@"17联想电脑",@"华硕电脑",@"MAC"],
  @[@"18鸡肉",@"鸭肉",@"牛肉",@"猪肉",@"羊肉"],
  @[@"19香菇",@"蘑菇",@"大头菜",@"青椒"],
  @[@"20花生油",@"大豆油",@"葵花籽油",@"芝麻香油"],
  @[@"21花椒",@"陈皮",@"八角"]
  ];
    }
    return _rightDataArr;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.rightDataArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    NSArray *arr = self.rightDataArr[section];
    return arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSArray * data = self.rightDataArr[indexPath.section];
    
    cell.textLabel.text = data[indexPath.row];
    return cell;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UITableViewHeaderFooterView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"headerView"];
    
    headerView.textLabel.text = [NSString stringWithFormat:@"第%ld区",section+1];
    return headerView;
}


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.frame = CGRectMake(120, 64,self.view.frame.size.width-120, self.view.frame.size.height-64);
    self.view.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.rightTableView];
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_delegate && [_delegate respondsToSelector:@selector(rightViewControllerDelegate:withIndexPatch:)]) {
        [_delegate rightViewControllerDelegate:self withIndexPatch:indexPath];
    }
}

//头将出现
-(void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section{
    
    if (_delegate && [self.delegate respondsToSelector:@selector(rightViewControllerDelegateHeaderViewAppear:withIndexPatch:)] && !_isScrollUp && _ifScroll) {

        [_delegate rightViewControllerDelegateHeaderViewAppear:self withIndexPatch:section];
    }
}
//头讲消失
-(void)tableView:(UITableView *)tableView didEndDisplayingHeaderView:(UIView *)view forSection:(NSInteger)section{
    
    if (_delegate && [self.delegate respondsToSelector:@selector(rightViewControllerDelegateHeaderViewdisappear:withIndexPatch:)] && _isScrollUp &&_ifScroll) {
        //上滑才执行
        [_delegate rightViewControllerDelegateHeaderViewdisappear:self withIndexPatch:section+1];
    }
}

//主要判断向上滑动还是向下滑动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    _isScrollUp = _lastOffsetY < scrollView.contentOffset.y;
    _lastOffsetY = scrollView.contentOffset.y;
    
    //isDragging  Dragging 拖拉
    if (scrollView.isDragging) {
        
        _ifScroll = YES;
    }
}

//滚动到制定的NSIndexPath
-(void)scrollToSelectIndexPath:(NSIndexPath *)path withRightTableViewScroll:(BOOL)ifScroll{
    NSLog(@"%ld",path.row);
   
    _ifScroll = ifScroll;
    [self.rightTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:path.row] animated:YES scrollPosition:UITableViewScrollPositionTop];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
