//
//  leftViewController.h
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface leftViewController : UIViewController

@end
