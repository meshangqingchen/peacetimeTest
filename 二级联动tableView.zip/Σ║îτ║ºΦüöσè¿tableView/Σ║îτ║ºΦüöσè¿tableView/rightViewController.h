//
//  rightViewController.h
//  二级联动tableView
//
//  Created by 3D on 16/7/4.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>


@class rightViewController;
@protocol rightViewControllerDeldgate <NSObject>

-(void)rightViewControllerDelegate:(rightViewController *)vc withIndexPatch:(NSIndexPath *)ptch;


-(void)rightViewControllerDelegateHeaderViewAppear:(rightViewController *)vc withIndexPatch:(NSInteger )section;
-(void)rightViewControllerDelegateHeaderViewdisappear:(rightViewController *)vc withIndexPatch:(NSInteger )section;

@end


@interface rightViewController : UIViewController

@property(nonatomic,weak)id <rightViewControllerDeldgate> delegate;

-(void)scrollToSelectIndexPath:(NSIndexPath *)path withRightTableViewScroll:(BOOL)ifScroll;
@end
