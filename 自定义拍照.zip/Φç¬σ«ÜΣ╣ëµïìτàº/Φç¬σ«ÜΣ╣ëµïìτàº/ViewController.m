//
//  ViewController.m
//  视频录制
//
//  Created by 3D on 16/9/15.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>
typedef void(^PropertyChangeBlock)(AVCaptureDevice *captureDevice);
@interface ViewController ()
@property(nonatomic,strong) AVCaptureSession *captureSession;//负责输入和输出设备之间的数据传递
@property(nonatomic,strong) AVCaptureDeviceInput *captureDeviceInput;//负责从AVCaptureDevice获得输入数据
@property(nonatomic,strong)  AVCaptureStillImageOutput *captureStillImageOutput;//照片输出流
@property (strong,nonatomic) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;//相机拍摄预览图层
@property (strong, nonatomic) UIView *viewContainer;
@property (strong, nonatomic) UIButton *takeButton;//拍照按钮
@property (strong, nonatomic) UIButton *flashAutoButton;//自动闪光灯按钮
@property (strong, nonatomic) UIButton *flashOnButton;//打开闪光灯按钮
@property (strong, nonatomic) UIButton *flashOffButton;//关闭闪光灯按钮

@property(nonatomic,strong) UIButton *exchangeCameraBT; //转换摄像头
@property (strong, nonatomic) UIImageView *focusCursor; //聚焦光标
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.flashAutoButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 60, 50)];
    _flashAutoButton.backgroundColor  =[UIColor greenColor];
    [_flashAutoButton setTitle:@"自动闪" forState:0];
    [_flashAutoButton addTarget:self action:@selector(flashAutoButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_flashAutoButton];
    
    self.flashOnButton = [[UIButton alloc]initWithFrame:CGRectMake(70, 0, 60, 50)];
    _flashOnButton.backgroundColor  =[UIColor greenColor];
    [_flashOnButton setTitle:@"开闪" forState:0];
    [_flashOnButton addTarget:self action:@selector(flashOnButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_flashOnButton];
    
    self.flashOffButton = [[UIButton alloc]initWithFrame:CGRectMake(140, 0, 60, 50)];
    _flashOffButton.backgroundColor = [UIColor greenColor];
    [_flashOffButton setTitle:@"关闪" forState:0];
    [_flashOffButton addTarget:self action:@selector(flashOffButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_flashOffButton];
    
    self.exchangeCameraBT = [[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width-100, 0, 100, 50)];
    _exchangeCameraBT.backgroundColor = [UIColor greenColor];
    [_exchangeCameraBT setTitle:@"转换摄像头" forState:0];
    [_exchangeCameraBT addTarget:self action:@selector(exchangeCameraBTClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_exchangeCameraBT];
    //拍照
    self.takeButton = [[UIButton alloc]initWithFrame:CGRectMake((self.view.frame.size.width)/2-30, 500, 60, 50)];
    _takeButton.backgroundColor = [UIColor greenColor];
    [_takeButton setTitle:@"拍照" forState:0];
    [_takeButton addTarget:self action:@selector(takeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_takeButton];
    
    self.viewContainer = [[UIView alloc]initWithFrame:CGRectMake(0, 50, self.view.frame.size.width, self.view.frame.size.width)];
    _viewContainer.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:self.viewContainer];
    
    _captureSession = [[AVCaptureSession alloc]init];
    if ([_captureSession canSetSessionPreset:AVCaptureSessionPreset1280x720]) {
        //设置分辨率
        _captureSession.sessionPreset = AVCaptureSessionPreset1280x720;
    }
    //获取设备
    AVCaptureDevice *captureDevices = [self getCameraDeviceWithPosition:AVCaptureDevicePositionBack];//AVCaptureDevicePositionBack 后置摄像头
    if (!captureDevices) {
        NSLog(@"取得后置摄像头时出现问题.");
        return;
    }
    NSError *error = nil;
    //初始化输入设备对输入对象,用于获得输入数据
    _captureDeviceInput = [[AVCaptureDeviceInput alloc]initWithDevice:captureDevices error:&error];
    if (error) {
        NSLog(@"取得设备输入对象时出错，错误原因：%@",error.localizedDescription);
        return;
    }
    //初始化设备输出对象,用于获得输出数据
    _captureStillImageOutput = [[AVCaptureStillImageOutput alloc]init];
    NSDictionary *outputSettings = @{AVVideoCodecKey:AVVideoCodecJPEG};
    [_captureStillImageOutput setOutputSettings:outputSettings];//输出设置
    
    //将设备输入添加到会话中
    if ([_captureSession canAddInput:_captureDeviceInput]) {
        [_captureSession addInput: _captureDeviceInput];
    }
    
    //讲设备输出添加到会话中
    if ([_captureSession canAddOutput:_captureStillImageOutput]) {
        [_captureSession addOutput:_captureStillImageOutput];
    }
    
    //创建视频展示层,用于实时展示摄像镜头状态
    _captureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc]initWithSession:_captureSession];
    //    _captureVideoPreviewLayer.session
    CALayer *layer=self.viewContainer.layer;
    layer.masksToBounds=YES;
    _captureVideoPreviewLayer.frame=layer.bounds;
    
    _captureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [layer addSublayer:_captureVideoPreviewLayer];
    
    [self addNotificationToCaptureDevice:captureDevices];
    [self addGenstureRecognizer];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.captureSession startRunning];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.captureSession stopRunning];
}

-(void)dealloc{
    [self removeNotification];
}

#define mark 获取指定位置摄像头
-(AVCaptureDevice *)getCameraDeviceWithPosition:(AVCaptureDevicePosition)position{
    NSArray *cameras = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *camera in cameras) {
        if ([camera position] == position) {
            return camera;
        }
    }
    return nil;
}

#pragma mark 通知方法
//添加摄像头捕获区域发生改变通知
-(void)addNotificationToCaptureDevice:(AVCaptureDevice *)captureDevice{
    //注意添加区域改变捕获通知必须首先设置设备允许捕获
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        captureDevice.subjectAreaChangeMonitoringEnabled = YES;
    }];
    NSNotificationCenter *notificationCenter= [NSNotificationCenter defaultCenter];
    //捕获区域发生改变
    [notificationCenter addObserver:self selector:@selector(areaChange:) name:AVCaptureDeviceSubjectAreaDidChangeNotification object:captureDevice];
}
//移除摄像头捕获区域发生改变通知
-(void)removeNotificationFromCaptureDevice:(AVCaptureDevice*)captureDevice{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self name:AVCaptureDeviceSubjectAreaDidChangeNotification object:captureDevice];
}
/**
 *  移除所有通知
 */
-(void)removeNotification{
    NSNotificationCenter *notificationCenter= [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self];
}

/**
 *  改变设备属性的统一操作方法
 *  @param propertyChange 属性改变操作
 */
-(void)changeDeviceProperty:(PropertyChangeBlock)propertyChange{
    AVCaptureDevice *captureDevice= [self.captureDeviceInput device];
    NSError *error;
    //注意改变设备属性前一定要首先调用lockForConfiguration:调用完之后使用unlockForConfiguration方法解锁
    if ([captureDevice lockForConfiguration:&error]) {
        propertyChange(captureDevice);
        [captureDevice unlockForConfiguration];
    }else{
        NSLog(@"设置设备属性过程发生错误，错误信息：%@",error.localizedDescription);
    }
}

/**
 *  捕获区域改变
 *
 *  @param notification 通知对象
 */
-(void)areaChange:(NSNotification *)notification{
    NSLog(@"捕获区域改变...");
}

/**
 * 添加手势点击时聚焦
 */
-(void)addGenstureRecognizer{
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapScreen:)];
    [self.viewContainer addGestureRecognizer:tapGesture];
}
-(void)tapScreen:(UITapGestureRecognizer*)tapGesture{
    NSLog(@"asd");
    CGPoint point = [tapGesture locationInView:self.viewContainer];
    //将ui坐标转化为摄像头坐标
    CGPoint cameraPoint = [self.captureVideoPreviewLayer captureDevicePointOfInterestForPoint:point];
    [self setFocusCursorWithPoint:point];
    [self focusWithMode:AVCaptureFocusModeAutoFocus exposureMode:AVCaptureExposureModeAutoExpose atPoint:cameraPoint];
}

#pragma mark 聚焦点位置 曝光点位置设置
/**
 * 设置聚焦光点 设置聚焦光标位置
 */
-(void)setFocusCursorWithPoint:(CGPoint)point{
    //将那个ImageView 动画出来到聚焦点
}

/**
 *  真正设置聚焦点  focus聚焦  exposure曝光
 */
-(void)focusWithMode:(AVCaptureFocusMode)focusMode exposureMode:(AVCaptureExposureMode)exposureMode atPoint:(CGPoint)point{
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        //是的如果接收器支持集中模式,没有否则]
        if ([captureDevice isFocusModeSupported:focusMode]) {
            //AVCaptureFocusModeAutoFocus  表明该设备应自动对焦模式AVCaptureFocusModeLocked一次,然后改变焦点
            [captureDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
        }
        //表示接收方是否支持感兴趣的焦点 接收机的focusPointOfInterest属性只能设置如果这个属性返回YES。
        if ([captureDevice isFocusPointOfInterestSupported]) {
            //显示当前接收器的感兴趣的焦点,如果它有一个
            [captureDevice setFocusPointOfInterest:point];
        }
        //是的如果接收器支持给定的曝光模式,没有否则
        if ([captureDevice isExposureModeSupported:exposureMode]) {
            //AVCaptureExposureModeAutoExpose  表明该设备应自动调整曝光一次,然后改变曝光模式AVCaptureExposureModeLocked。
            [captureDevice setExposureMode:AVCaptureExposureModeContinuousAutoExposure];
        }
        //表示接收方是否支持曝光的兴趣点 接收机的exposurePointOfInterest属性只能设置如果这个属性返回YES。
        if ([captureDevice isExposurePointOfInterestSupported]) {
            [captureDevice setExposurePointOfInterest:point];
        }
    }];
}

#pragma mark 拍照模式设置
/**
 *  设置闪光灯模式
 *  @param flashMode 闪光灯模式
 */
-(void)setFlashMode:(AVCaptureFlashMode )flashMode{
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isFlashModeSupported:flashMode]) {
            [captureDevice setFlashMode:flashMode];
        }
    }];
}
/**
 *  设置聚焦模式
 *  @param focusMode 聚焦模式
 */
-(void)setFocusMode:(AVCaptureFocusMode )focusMode{
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isFocusModeSupported:focusMode]) {
            [captureDevice setFocusMode:focusMode];
        }
    }];
}
/**
 *  设置曝光模式
 *  @param exposureMode 曝光模式
 */
-(void)setExposureMode:(AVCaptureExposureMode)exposureMode{
    [self changeDeviceProperty:^(AVCaptureDevice *captureDevice) {
        if ([captureDevice isExposureModeSupported:exposureMode]) {
            [captureDevice setExposureMode:exposureMode];
        }
    }];
}

#pragma mark 按钮方法
/**
 * 拍照片
 */
-(void)takeButtonClick:(UIButton*)sender{
    //根据设备输出获得连接
    AVCaptureConnection *captureConnection = [self.captureStillImageOutput connectionWithMediaType:AVMediaTypeVideo];
    //根据链接取得设备输出的数据
    [self.captureStillImageOutput captureStillImageAsynchronouslyFromConnection:captureConnection completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
        if (imageDataSampleBuffer) {
            NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
            UIImage *image=[UIImage imageWithData:imageData];
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
        }
    }];
}
/**
 * 转换摄像头
 */
-(void)exchangeCameraBTClick:(UIButton*)sender{
    AVCaptureDevice *currentDevice = [self.captureDeviceInput device];
    AVCaptureDevicePosition currentPosition = [currentDevice position];// 设备的枚举值 (前摄像头 或者后摄像头)
    [self removeNotificationFromCaptureDevice:currentDevice];
    
    AVCaptureDevicePosition toChangePosition=AVCaptureDevicePositionFront;
    if (currentPosition==AVCaptureDevicePositionUnspecified||currentPosition==AVCaptureDevicePositionFront ) {
        toChangePosition = AVCaptureDevicePositionBack;
    }
    AVCaptureDevice *toChangeDevice= [self getCameraDeviceWithPosition:toChangePosition];
    [self addNotificationToCaptureDevice:toChangeDevice];
    NSError *error;
    //创建新的设备输入对象
    AVCaptureDeviceInput *toChangeDeviceInput = [[AVCaptureDeviceInput alloc]initWithDevice:toChangeDevice error:&error];
    
    //改变会话的配置前一定要先开启配置,配置完成后提交配置改变
    [self.captureSession beginConfiguration];
    //移除原有输入对象 加入新输入对象 在不新的输入对象赋值给self.captureDeviceInput
    [self.captureSession removeInput:self.captureDeviceInput];
    if ([self.captureSession canAddInput:toChangeDeviceInput]) {
        [self.captureSession addInput:toChangeDeviceInput];
        self.captureDeviceInput = toChangeDeviceInput;
    }
    //提交会话配置
    [self.captureSession commitConfiguration];
}

-(void)flashAutoButtonClick:(UIButton*)sender{
    [self setFlashMode:AVCaptureFlashModeAuto];
    NSLog(@"自动开摄像头");
}

-(void)flashOnButtonClick:(UIButton*)sender{
    [self setFlashMode:AVCaptureFlashModeOn];
    NSLog(@"开摄像头");
    
}

-(void)flashOffButtonClick:(UIButton*)sender{
    [self setFlashMode:AVCaptureFlashModeOff];
    NSLog(@"关摄像头");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"123456789p");
}

@end

















































