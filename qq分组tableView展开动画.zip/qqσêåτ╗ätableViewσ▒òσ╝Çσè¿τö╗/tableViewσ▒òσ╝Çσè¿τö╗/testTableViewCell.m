//
//  testTableViewCell.m
//  tableView展开动画
//
//  Created by 3D on 16/6/27.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "testTableViewCell.h"

@implementation testTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.nameLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, 100, 40)];
        [self.contentView addSubview:self.nameLable];
        
        self.ageLable = [[UILabel alloc]initWithFrame:CGRectMake(200, 10, 100, 40)];
        [self.contentView addSubview:self.ageLable];
    }
    return self;
}
@end
