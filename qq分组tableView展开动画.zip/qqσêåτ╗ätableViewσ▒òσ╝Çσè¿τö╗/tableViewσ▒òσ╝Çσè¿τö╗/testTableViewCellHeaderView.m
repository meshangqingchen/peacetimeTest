//
//  testTableViewCellHeaderView.m
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "testTableViewCellHeaderView.h"
#import "testTableViewCellHeaderView+transform.h"
@interface testTableViewCellHeaderView ()
//@property(nonatomic,strong)UIButton

@end


@implementation testTableViewCellHeaderView
-(instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.classLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 2, 100, 26)];
        self.classLable.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:self.classLable];
    
        UIButton *bution = [[UIButton alloc]initWithFrame:CGRectMake(200, 2, 100, 26)];
        bution.backgroundColor = [UIColor yellowColor];
        [self.contentView addSubview:bution];
        [bution addTarget:self action:@selector(butionEvent:) forControlEvents:UIControlEventTouchUpInside];
        
        UIView *imageBackView = [[UIView alloc]initWithFrame:CGRectMake(310, 2, 26, 26)];
        self.imageBackView = imageBackView;
        
        self.defaultTransform1111 =    self.imageBackView.transform;
        
        [self.contentView addSubview:imageBackView];
        self.imageBackView.backgroundColor = [UIColor yellowColor];
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 26, 26)];
        
        [self.imageBackView addSubview:imageView];
        imageView.backgroundColor = [UIColor redColor];
        imageView.image = [UIImage imageNamed:@"arrows_next"];
    }
    
    return self;
}

-(void)butionEvent:(UIButton *)sender{
    if (_delegate && [self.delegate respondsToSelector:@selector(customTestTableViewCellHeaderView:)]) {
        [_delegate customTestTableViewCellHeaderView:self];
        
    }
}

-(void)normalToSelect:(BOOL)expend{

    [UIView animateWithDuration:0.25 animations:^{
        self.imageBackView.transform = CGAffineTransformRotate(self.transform, M_PI_2);
    }];
}

-(void)SelectToNormal:(BOOL)expend{

    [UIView animateWithDuration:0.25 animations:^{
        self.imageBackView.transform = CGAffineTransformIdentity;
    }];
    
}



@end



