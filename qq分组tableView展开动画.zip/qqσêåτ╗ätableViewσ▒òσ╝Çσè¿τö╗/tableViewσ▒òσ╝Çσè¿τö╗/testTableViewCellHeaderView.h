//
//  testTableViewCellHeaderView.h
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@class testTableViewCellHeaderView;
@protocol testTableViewCellHeaderViewDelegate <NSObject>

-(void)customTestTableViewCellHeaderView:(testTableViewCellHeaderView*)headerView;

@end

@interface testTableViewCellHeaderView : UITableViewHeaderFooterView
@property(nonatomic,strong)UILabel *classLable;
@property(nonatomic,weak)id<testTableViewCellHeaderViewDelegate>delegate;

@property(nonatomic,assign)NSInteger section;


@property(nonatomic,strong)UIView *imageBackView;

@property(nonatomic) CGAffineTransform defaultTransform1111;


-(void)normalToSelect:(BOOL)expend;
-(void)SelectToNormal:(BOOL)expend;
@end
