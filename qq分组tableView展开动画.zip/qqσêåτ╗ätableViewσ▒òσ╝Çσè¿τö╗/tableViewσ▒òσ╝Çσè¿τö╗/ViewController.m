//
//  ViewController.m
//  tableView展开动画
//
//  Created by 3D on 16/6/27.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "ViewController.h"
#import "testTableViewCell.h"
#import "testTableViewCellHeaderView.h"
#import "testModel.h"

static NSString * indefierForCell = @"cell";
static NSString * indefierForHeaderView = @"headerView";

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,testTableViewCellHeaderViewDelegate>
@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *modelArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    for (NSDictionary *dic in self.dataArr) {
        testModel * model = [[testModel alloc]initWithDictionary:dic];
        model.expend = NO;
        [self.modelArr addObject:model];
    }
    NSLog(@"==%@",self.modelArr);
    testModel * model = self.modelArr[0];
    NSLog(@"===%@",model);
    NSLog(@"=========%@,%@",model.zuName,model.people);
    
    testPeopleModel * peomodel = model.people[0];
    NSLog(@"peomodel===%@  %@  %@",peomodel,peomodel.name,peomodel.age);

    [self.view addSubview:self.tableView];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    testModel *model = self.modelArr[section];
   
    if (model.expend) {
        return model.people.count;
    }else{
        return 0;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    testModel *model = self.modelArr[indexPath.section];
    testPeopleModel *peopleMdoel = model.people[indexPath.row];
    
    
    testTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.nameLable.text = peopleMdoel.name;
    cell.ageLable.text = [peopleMdoel.age description];
    return cell;
    
}


- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    testTableViewCellHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:indefierForHeaderView];
    headerView.delegate = self;
    
    testModel * model = self.modelArr[section];
    headerView.classLable.text = model.zuName;
    headerView.section = section;
    
    // 下面点击展开model.expend 就会变成yes 那么是no就保持原来的状态就好了 不写else的话 比如点开了第一个 第三个是重用的第一个. 滑动到第三个保持的是没向下 但是他的model.expend时no 经过if判断就会保持默认的  .这时候第一个 本来应该向下的由于 第三个就是第一个 第三个变了 所以第一个也变成默认的了 所以写上else 在让他 旋转90  .但是坑爹的 要是第一个没有被重用 也会直线else 啊旋转90度. 所以先不管三七二十一让他恢复默认在旋转90度就是正好的.
    if (!model.expend) {
        headerView.imageBackView.transform = headerView.defaultTransform1111;
    }else{
        headerView.imageBackView.transform = headerView.defaultTransform1111;
        headerView.imageBackView.transform = CGAffineTransformRotate(headerView.imageBackView.transform, M_PI_2);

    }
    
    return headerView;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 30;
}


//hearderView的代理
-(void)customTestTableViewCellHeaderView:(testTableViewCellHeaderView *)headerView{

    NSLog(@"asdad");
    
    NSInteger section = headerView.section;
    testModel *model = self.modelArr[section];
    if (model.expend) {
        model.expend = NO;
        // 收缩
        [headerView SelectToNormal:NO];
        NSMutableArray *indexPatchs = @[].mutableCopy;
        for (int i = 0; i<model.people.count; i++) {
//            [indexPatchs addObject:[NSIndexPath indexPathForItem:i inSection:section]];
        
            
            [indexPatchs addObject:[NSIndexPath indexPathForRow:i inSection:section]];
        }
        [self.tableView deleteRowsAtIndexPaths:indexPatchs.copy withRowAnimation:UITableViewRowAnimationFade];
        
    }else{
        model.expend = YES;
        //展开
        [headerView normalToSelect:NO];
        NSMutableArray *indexPatchs = @[].mutableCopy;
        for (int i = 0; i<model.people.count; i++) {
            [indexPatchs addObject:[NSIndexPath indexPathForItem:i inSection:section]];
        }
        [self.tableView insertRowsAtIndexPaths:indexPatchs.copy withRowAnimation:UITableViewRowAnimationFade];
        
    }
    

}



- (UITableView *)tableView {
	if(_tableView == nil) {
		_tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;

        [_tableView registerClass:[testTableViewCell class] forCellReuseIdentifier:indefierForCell];
        
        [_tableView registerClass:[testTableViewCellHeaderView class] forHeaderFooterViewReuseIdentifier:indefierForHeaderView];
}
	return _tableView;
}

- (NSMutableArray *)dataArr {
	if(_dataArr == nil) {
        _dataArr =
         @[@{@"zuName":@"jia0",
             @"people":
 @[@{@"name":@"aaa",@"age":@(1)},
   @{@"name":@"bbb",@"age":@(2)},
   @{@"name":@"ccc",@"age":@(3)},
   @{@"name":@"ddd",@"age":@(4)},
   @{@"name":@"eee",@"age":@(5)},
   @{@"name":@"fff",@"age":@(6)},
   @{@"name":@"ggg",@"age":@(7)},
   @{@"name":@"hhh",@"age":@(8)},
   @{@"name":@"iii",@"age":@(9)},
   @{@"name":@"jjj",@"age":@(10)}]},
  
            @{@"zuName":@"jia1",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]}, 
  
            
            @{@"zuName":@"jia2",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia3",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia4",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia5",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia6",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia7",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia8",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia9",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia10",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia11",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia12",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
            
            
            @{@"zuName":@"jia13",
              @"people":
  @[@{@"name":@"aaa",@"age":@(1)},
    @{@"name":@"bbb",@"age":@(2)},
    @{@"name":@"ccc",@"age":@(3)},
    @{@"name":@"ddd",@"age":@(4)},
    @{@"name":@"eee",@"age":@(5)},
    @{@"name":@"fff",@"age":@(6)},
    @{@"name":@"ggg",@"age":@(7)},
    @{@"name":@"hhh",@"age":@(8)},
    @{@"name":@"iii",@"age":@(9)},
    @{@"name":@"jjj",@"age":@(10)}]},
].mutableCopy;
	}
	return _dataArr.mutableCopy;
}

- (NSMutableArray *)modelArr {
	if(_modelArr == nil) {
		_modelArr = [[NSMutableArray alloc] init];
	}
	return _modelArr;
}

@end
