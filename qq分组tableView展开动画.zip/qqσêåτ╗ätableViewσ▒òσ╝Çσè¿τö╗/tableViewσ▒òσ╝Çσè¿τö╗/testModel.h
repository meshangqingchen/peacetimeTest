//
//  testModel.h
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <Foundation/Foundation.h>
@class testPeopleModel;

@interface testModel : NSObject

@property(nonatomic,strong)NSString *zuName;
@property(nonatomic,strong)NSArray <testPeopleModel *> *people;

@property(nonatomic,assign)BOOL expend;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
@end

@interface testPeopleModel : NSObject
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSNumber *age;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
@end