//
//  testModel.m
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "testModel.h"

@implementation testModel






- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    if (self = [super init]) {
        self.zuName = dictionary[@"zuName"];
        NSMutableArray *testPeopleModelArr = [NSMutableArray array];
        NSArray *arr = dictionary[@"people"];
        for (NSDictionary * dic in arr) {
            testPeopleModel *peopleModel = [[testPeopleModel alloc]initWithDictionary:dic];
            
            [testPeopleModelArr addObject:peopleModel];
        }
        self.people = testPeopleModelArr.copy;
  
    }
    
    return self;
}

@end


@implementation testPeopleModel

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    if (self = [super init]) {
        self.name = dictionary[@"name"];
        self.age = dictionary[@"age"];
    }
    return self;
}

@end








