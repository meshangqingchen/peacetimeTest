//
//  testTableViewCellHeaderView+transform.h
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "testTableViewCellHeaderView.h"
#import <Foundation/Foundation.h>
@interface testTableViewCellHeaderView (transform)

/**
 *  在初始化的时候保存transform的值
 */
@property (nonatomic) CGAffineTransform  defaultTransform;
@end
