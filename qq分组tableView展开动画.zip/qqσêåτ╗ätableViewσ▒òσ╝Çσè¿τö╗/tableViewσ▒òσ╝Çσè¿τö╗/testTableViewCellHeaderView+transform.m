//
//  testTableViewCellHeaderView+transform.m
//  tableView展开动画
//
//  Created by 3D on 16/6/28.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "testTableViewCellHeaderView+transform.h"
#import <objc/runtime.h>


@implementation testTableViewCellHeaderView (transform)


/**
 *  defaultTransform
 */
NSString * const _recognizerDefaultTransform = @"_recognizerDefaultTransform";

- (void)setDefaultTransform:(CGAffineTransform)defaultTransform {
    
    NSValue *value = [NSValue valueWithCGAffineTransform:defaultTransform];
    objc_setAssociatedObject(self, (__bridge const void *)(_recognizerDefaultTransform),
                             value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGAffineTransform)defaultTransform {
    
    NSValue *value = objc_getAssociatedObject(self, (__bridge const void *)(_recognizerDefaultTransform));
    return [value CGAffineTransformValue];
}

@end
