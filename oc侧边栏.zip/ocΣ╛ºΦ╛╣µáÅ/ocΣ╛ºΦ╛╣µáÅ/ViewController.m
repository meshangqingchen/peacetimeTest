//
//  ViewController.m
//  oc侧边栏
//
//  Created by 3D on 16/7/6.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "ViewController.h"
#import "UIButton+rotate.h"

@interface ViewController ()<UIScrollViewDelegate>

@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIView *contentView;

@property(nonatomic,strong)UIButton *hanmburgerBtn;
@property(nonatomic,assign)BOOL isHiden;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    NSLog(@"111");
    self.view.backgroundColor = [UIColor blackColor];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new]
                                                  forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
    self.view.translatesAutoresizingMaskIntoConstraints = NO;
    
    //    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    NSLog(@"elf.view.frame.size.height===%f",self.view.frame.size.height);
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64)];
    
    self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width+80, self.view.frame.size.height-64);
    self.scrollView.delegate = self;
    self.scrollView.backgroundColor = [UIColor blueColor];
    self.scrollView.pagingEnabled = YES;
    self.scrollView.bounces = NO;
 
    self.scrollView.backgroundColor = [UIColor blueColor];
    [self.view addSubview:self.scrollView];
    
    self.contentView  = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width+80, self.scrollView.frame.size.height)];
   
    [self.scrollView addSubview:self.contentView];
    _contentView.backgroundColor = [UIColor yellowColor];
    [self creatChiledViewController];
    
    self.hanmburgerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 20, 20)];
    [self.hanmburgerBtn setImage:[UIImage imageNamed:@"Hamburger"] forState:UIControlStateNormal];
    [self.hanmburgerBtn addTarget:self action:@selector(HamburgerClick:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.hanmburgerBtn];
    
    
}



-(void)creatChiledViewController{

    self.rightVC = [[rightViewController alloc]init];
    [self addChildViewController:self.rightVC];
    [self.contentView addSubview:self.rightVC.view];
    
    
    self.leftVC = [[leftViewController alloc]init];
    [self addChildViewController:self.leftVC];
    [self.contentView addSubview:self.leftVC.view];
 
    self.leftVC.view.layer.anchorPoint = CGPointMake(1.0, 0.5);
    
    self.leftVC.view.layer.position = CGPointMake(80, self.leftVC.view.bounds.size.height/2.0);
    
    // 也可以不设置position下面返回 CATransform3DConcat
    //self.leftVC.view.layer.transform = [self transformForFraction:0];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{

    CGFloat multiplier = 1.0/CGRectGetWidth(self.leftVC.view.bounds);
    CGFloat offset = scrollView.contentOffset.x * multiplier;
    CGFloat fraction = 1.0 - offset;
    [self.hanmburgerBtn rotate:fraction];
    
    self.leftVC.view.alpha = fraction;
    self.leftVC.view.layer.transform = [self transformForFraction:offset];
    scrollView.pagingEnabled = scrollView.contentOffset.x < 80 ? YES : NO;
    _isHiden = !scrollView.pagingEnabled;
}


-(CATransform3D)transformForFraction:(CGFloat)fraction{
    CATransform3D identity = CATransform3DIdentity;
    identity.m34 = -1.0/1000.0;
    CGFloat angle = (double)(fraction * -M_PI_2);
    CGFloat xOffset = CGRectGetWidth(self.leftVC.view.bounds) * 0.5;

    CATransform3D rotateTransform = CATransform3DRotate(identity, angle, 0.0, 1.0, 0.0);
    CATransform3D translateTransform = CATransform3DMakeTranslation(xOffset, 0.0,0.0);
    
    return  rotateTransform;//CATransform3DConcat(rotateTransform, translateTransform);
}


-(void)HamburgerClick:(UIButton *)sender{
    
    CGFloat menuOffset = CGRectGetWidth(self.leftVC.view.bounds);
    if (!_isHiden) {
        [self.scrollView setContentOffset:CGPointMake(menuOffset, 0) animated:YES];
    }else{
    
        [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
    _isHiden = !_isHiden;
    
}
//leftVC 点击cell调用
-(void)hidenmenu{
     CGFloat menuOffset = CGRectGetWidth(self.leftVC.view.bounds);
    [self.scrollView setContentOffset:CGPointMake(menuOffset, 0) animated:YES];
    _isHiden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end























