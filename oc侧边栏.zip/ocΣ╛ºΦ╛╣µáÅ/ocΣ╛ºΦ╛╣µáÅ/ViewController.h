//
//  ViewController.h
//  oc侧边栏
//
//  Created by 3D on 16/7/6.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "leftViewController.h"
#import "rightViewController.h"
@interface ViewController : UIViewController

@property(nonatomic,strong)leftViewController *leftVC;
@property(nonatomic,strong)rightViewController *rightVC;

-(void)hidenmenu;
@end

