//
//  LCCTableViewCell.m
//  oc侧边栏
//
//  Created by 3D on 16/7/7.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "LCCTableViewCell.h"
#import "Masonry.h"
@implementation LCCTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.lccImageView = [[UIImageView alloc]init];
        
        [self.contentView addSubview:self.lccImageView];
        [self.lccImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.left.mas_equalTo(0);
            make.width.mas_equalTo(80);
        }];
        
        
        
    }
    return self;
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
