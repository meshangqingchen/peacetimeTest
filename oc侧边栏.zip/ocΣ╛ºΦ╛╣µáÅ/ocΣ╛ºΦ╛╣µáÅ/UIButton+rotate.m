//
//  UIButton+rotate.m
//  CKLeft3DMenuView
//
//  Created by 中青致学 on 16/1/2.
//  Copyright © 2016年 Yang_Cankun. All rights reserved.
//

#import "UIButton+rotate.h"

@implementation UIButton (rotate)
/**
 *  旋转
 *
 *  @param fraction 旋转的角度
 */
- (void)rotate:(CGFloat)fraction {
    CGFloat angle = (double)fraction * M_PI_2;
//    CGAffineTransform aaa = CGAffineTransformMakeRotation(angle);
//    
//    CGAffineTransform bbb = CGAffineTransformMakeTranslation(100,0);
//    
//    self.imageView.transform = CGAffineTransformConcat(aaa, bbb);
    
    self.imageView.transform = CGAffineTransformMakeRotation(angle);

    
//    self.imageView.layer.transform = CATransform3DIdentity;
//    self.imageView.layer.transform =  CATransform3DMakeRotation(angle, 1, 1, 0);

//    CATransform3D  yRotation= CATransform3DMakeRotation(angle, 0, 1, 0); // y 90
//    CATransform3D  xRotation= CATransform3DMakeRotation(angle, 1, 0, 0); // y 90
//  self.imageView.layer.transform =  CATransform3DConcat(yRotation, xRotation);
}

@end
