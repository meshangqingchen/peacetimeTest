//
//  AppDelegate.h
//  oc侧边栏
//
//  Created by 3D on 16/7/6.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

