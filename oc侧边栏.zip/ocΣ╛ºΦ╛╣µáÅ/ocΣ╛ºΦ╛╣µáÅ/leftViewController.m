//
//  leftViewController.m
//  oc侧边栏
//
//  Created by 3D on 16/7/6.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "leftViewController.h"
#import "LCCTableViewCell.h"
#import "UIColor+colorArray.h"
#import "ViewController.h"

@interface leftViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *leftTableView;

@property(nonatomic,strong)NSMutableArray *dataArr;

@end

@implementation leftViewController


-(NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = @[].mutableCopy;
    }
    return _dataArr;
}

-(UITableView *)leftTableView{
    if (!_leftTableView) {
        _leftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStylePlain];
        [_leftTableView registerClass:[LCCTableViewCell class] forCellReuseIdentifier:@"cell"];
        _leftTableView.delegate = self;
        _leftTableView.dataSource = self;
//        _leftTableView.rowHeight = self.view.bounds.size.height/7;
    }
    return _leftTableView;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArr.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LCCTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    NSDictionary *dic = self.dataArr[indexPath.row];
    cell.lccImageView.image = [UIImage imageNamed:dic[@"image"]];
    cell.lccImageView.backgroundColor = [UIColor colorArray:dic[@"colors"]];
    
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  MAX(80,(CGRectGetHeight(self.view.bounds)/(CGFloat)self.dataArr.count));}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"3333");
    
    
    
    self.view.frame = CGRectMake(0, 0, 80, self.view.frame.size.height-64);
    [self.view addSubview:self.leftTableView];
    self.view.backgroundColor = [UIColor blueColor];
    NSString *path  = [[NSBundle mainBundle] pathForResource:@"MenuItems" ofType:@"plist"];
    NSArray *arr = [[NSArray alloc]initWithContentsOfFile:path];
    [self.dataArr addObjectsFromArray:arr];
    //在 leftVC 点击cell 改变 rightVC.View的背景图和别景色 (首选的拿到rightVC 让rightVC执行自己的方法)
    ViewController * parentVC = (ViewController *)self.parentViewController;
    rightViewController *rightVC = parentVC.rightVC;
    //在get方法里执行方法
    rightVC.dataDic = self.dataArr.firstObject;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    ViewController * parentVC = (ViewController *)self.parentViewController;
    rightViewController *rightVC = parentVC.rightVC;
    //在get方法里执行方法
    rightVC.dataDic = self.dataArr[indexPath.row];
    
    [parentVC hidenmenu];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
