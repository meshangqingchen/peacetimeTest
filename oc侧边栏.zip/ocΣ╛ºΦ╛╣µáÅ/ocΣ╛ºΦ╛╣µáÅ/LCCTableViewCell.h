//
//  LCCTableViewCell.h
//  oc侧边栏
//
//  Created by 3D on 16/7/7.
//  Copyright © 2016年 3D. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCCTableViewCell : UITableViewCell
@property(nonatomic,strong)UIImageView *lccImageView;
@end
