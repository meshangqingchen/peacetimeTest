//
//  rightViewController.m
//  oc侧边栏
//
//  Created by 3D on 16/7/6.
//  Copyright © 2016年 3D. All rights reserved.
//

#import "rightViewController.h"
#import "UIColor+colorArray.h"
@interface rightViewController ()
@property(nonatomic,strong)UIImageView *backImageView;
@end

@implementation rightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor yellowColor];
    self.view.frame = CGRectMake(80, 0, self.view.frame.size.width, self.view.frame.size.height-64);
    
    self.backImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:self.backImageView];
    NSLog(@"2222");
    
}

-(void)setDataDic:(NSDictionary *)dataDic{
    _dataDic = dataDic;
    
    NSLog(@"__________%@",_dataDic);
    
//    UIImageView * backImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    _backImageView.image = [UIImage imageNamed:_dataDic[@"bigImage"]];
////    [self.view addSubview:_backImageView];
    self.view.backgroundColor = [UIColor colorArray:_dataDic[@"colors"]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
